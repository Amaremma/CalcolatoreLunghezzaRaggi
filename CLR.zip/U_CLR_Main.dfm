object Main_Form: TMain_Form
  Left = 0
  Top = 0
  Caption = 'Calcolatore Lunghezza Raggio'
  ClientHeight = 223
  ClientWidth = 509
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  Icon.Data = {
    0000010001001010100000000000280100001600000028000000100000002000
    00000100040000000000C000000000000000000000000000000000000000181A
    210073706D00373B5F006974A30040414700938F8B00484E650024293E002729
    2D00BDAF99005E698C004A5280008D95D0007E88B8007A818A00B6A392008722
    722BA3BBB44880772222BB3B266648874BAA33AA661A147462BA3AAAA4EE5E66
    222B33A33AEEEEBAB6BDD3CCD3EE5666222D32763AEEE440007A6702B2AE1074
    42B333CDD77E40046626BBAAA706400000000888488640000000000888411800
    080008888441E10808808888465FFF544448484115F599FF5151115FFFFF0000
    0000000000000000000000000000000000000000000000000000000000000000
    000000000000000000000000000000000000000000000000000000000000}
  Menu = MainMenu1
  OldCreateOrder = False
  OnShow = FInitMaiForm
  PixelsPerInch = 96
  TextHeight = 13
  object lblDiametroFlangia: TLabel
    Left = 24
    Top = 24
    Width = 102
    Height = 13
    Caption = 'diametro della flangia'
  end
  object lblDistFM: TLabel
    Left = 24
    Top = 48
    Width = 101
    Height = 13
    Caption = 'distanza tra le flange'
  end
  object lblDiametroForoRaggio: TLabel
    Left = 24
    Top = 67
    Width = 98
    Height = 13
    Caption = 'diametro foro raggio'
  end
  object lblDiametroCerchio: TLabel
    Left = 24
    Top = 86
    Width = 79
    Height = 13
    Caption = 'diametro cerchio'
  end
  object lblNumeroDiRaggi: TLabel
    Left = 24
    Top = 105
    Width = 74
    Height = 13
    Caption = 'numero di raggi'
  end
  object lblNumeroRaggiIncrociati: TLabel
    Left = 24
    Top = 129
    Width = 119
    Height = 13
    Caption = 'numero di raggi incrociati'
  end
  object lblLunghezzaCalcolataRaggio: TLabel
    Left = 24
    Top = 177
    Width = 143
    Height = 13
    Caption = 'lunghezza calcolata del raggio'
  end
  object lblDiametroFlangiaErr: TLabel
    Left = 282
    Top = 24
    Width = 152
    Height = 13
    Caption = 'digitare un numero diverso da 0'
    Color = clRed
    ParentColor = False
  end
  object lblDistFMErr: TLabel
    Left = 282
    Top = 48
    Width = 152
    Height = 13
    Caption = 'digitare un numero diverso da 0'
    Color = clRed
    ParentColor = False
  end
  object lblDiametroForoRaggioErr: TLabel
    Left = 282
    Top = 67
    Width = 152
    Height = 13
    Caption = 'digitare un numero diverso da 0'
    Color = clRed
    ParentColor = False
  end
  object lblDiametroCerchioErr: TLabel
    Left = 282
    Top = 86
    Width = 152
    Height = 13
    Caption = 'digitare un numero diverso da 0'
    Color = clRed
    ParentColor = False
  end
  object lblNumeroDiRaggiErr: TLabel
    Left = 282
    Top = 105
    Width = 152
    Height = 13
    Caption = 'digitare un numero diverso da 0'
    Color = clRed
    ParentColor = False
  end
  object lblNumeroRaggiIncrociatiErr: TLabel
    Left = 282
    Top = 124
    Width = 152
    Height = 13
    Caption = 'digitare un numero diverso da 0'
    Color = clRed
    ParentColor = False
  end
  object edtDiametroFlangia: TEdit
    Left = 221
    Top = 21
    Width = 50
    Height = 21
    Hint = 'misura rilevata al centro del foro del raggio'
    NumbersOnly = True
    ParentShowHint = False
    ShowHint = True
    TabOrder = 0
    TextHint = 'distanza rilevata al centro del foro del raggio'
    OnExit = CalcolaraggioFlangia
  end
  object edtDistF: TEdit
    Left = 221
    Top = 45
    Width = 50
    Height = 21
    NumbersOnly = True
    TabOrder = 1
    OnExit = SemiDistFlange
  end
  object edtDiametroForoRaggio: TEdit
    Left = 221
    Top = 64
    Width = 50
    Height = 21
    TabOrder = 2
    OnExit = CalcolaraggioFororaggio
  end
  object edtDiametroCerchio: TEdit
    Left = 221
    Top = 83
    Width = 50
    Height = 21
    Hint = 'misura all'#39'innesto delle nipples'
    NumbersOnly = True
    ParentShowHint = False
    ShowHint = True
    TabOrder = 3
    OnExit = CalcolaRaggioCerchio
  end
  object edtNumeroDiRaggi: TEdit
    Left = 221
    Top = 102
    Width = 50
    Height = 21
    NumbersOnly = True
    TabOrder = 4
    OnExit = VerificaImmissioneNumeroRaggi
  end
  object edtNumeroRaggiIncrociati: TEdit
    Left = 221
    Top = 121
    Width = 50
    Height = 21
    NumbersOnly = True
    TabOrder = 5
    OnExit = VerificaImmissioneNumeroIncroci
  end
  object edtLunghezzaCalcolataRaggio: TEdit
    Left = 221
    Top = 169
    Width = 50
    Height = 21
    Hint = 'visualizza la lunghezza in millimetri'
    Enabled = False
    NumbersOnly = True
    ParentShowHint = False
    ReadOnly = True
    ShowHint = True
    TabOrder = 6
    Text = 'Calcolatore'
  end
  object btnCalcolaLunghezzaRaggio: TButton
    Left = 173
    Top = 196
    Width = 140
    Height = 25
    Caption = 'Calcola Lunghezza raggio'
    TabOrder = 7
    OnClick = CalcoloLunghezzaRaggio
  end
  object MainMenu1: TMainMenu
    object File1: TMenuItem
      Caption = 'File'
      object Esci1: TMenuItem
        Caption = 'Esci'
        OnClick = Esci1Click
      end
    end
  end
end
