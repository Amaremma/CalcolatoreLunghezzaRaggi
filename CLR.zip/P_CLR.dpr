program P_CLR;

uses
  Vcl.Forms,
  U_CLR_Main in 'U_CLR_Main.pas' {Main_Form};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TMain_Form, Main_Form);
  Application.Run;
end.
